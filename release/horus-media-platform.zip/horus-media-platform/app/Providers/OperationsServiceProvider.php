<?php

namespace App\Providers;

use App\Http\Controllers\Admin\OperationsController;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\ServiceProvider;

class OperationsServiceProvider extends ServiceProvider
{
    public function boot(): void
    {
        Route::middleware(['web', 'auth', 'active', 'verified', 'admin.2fa'])->group(function (): void {
            Route::get('/admin/operations', [OperationsController::class, 'index'])->middleware('permission:operations.view')->name('admin.operations.index');
            Route::post('/admin/operations/controls', [OperationsController::class, 'control'])->middleware(['permission:operations.manage', 'throttle:sensitive'])->name('admin.operations.controls');
            Route::post('/admin/operations/jobs/{uuid}/retry', [OperationsController::class, 'retryFailedJob'])->middleware(['permission:operations.manage', 'throttle:sensitive'])->name('admin.operations.jobs.retry');
            Route::delete('/admin/operations/jobs/{uuid}', [OperationsController::class, 'forgetFailedJob'])->middleware(['permission:operations.manage', 'throttle:sensitive'])->name('admin.operations.jobs.forget');
            Route::post('/admin/operations/loader/rollback', [OperationsController::class, 'rollbackLoader'])->middleware(['permission:operations.manage', 'throttle:sensitive'])->name('admin.operations.loader.rollback');
        });
    }
}
