<?php

namespace App\Services\Audit;

use App\Models\AuditLog;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Http\Request;

final class AuditRecorder
{
    public function record(
        string $event,
        ?string $organizationId = null,
        ?Model $actor = null,
        ?Model $auditable = null,
        array $oldValues = [],
        array $newValues = [],
        array $metadata = [],
        ?Request $request = null,
    ): AuditLog {
        $request ??= request();
        $metadata = array_merge([
            'method' => $request->method(),
            'route' => $request->route()?->getName(),
        ], $metadata);

        return AuditLog::query()->create([
            'organization_id' => $organizationId,
            'actor_type' => $actor?->getMorphClass(),
            'actor_id' => $actor?->getKey(),
            'event' => $event,
            'auditable_type' => $auditable?->getMorphClass(),
            'auditable_id' => $auditable?->getKey(),
            'request_id' => $request->header('X-Request-ID'),
            'ip_address' => $request->ip(),
            'user_agent' => mb_substr((string) $request->userAgent(), 0, 1024),
            'old_values' => $this->redact($oldValues) ?: null,
            'new_values' => $this->redact($newValues) ?: null,
            'metadata' => $this->redact($metadata) ?: null,
        ]);
    }

    private function redact(array $values): array
    {
        $sensitive = ['password', 'password_confirmation', 'token', 'token_hash', 'secret', 'two_factor_secret', 'two_factor_recovery_codes', 'payment_details', 'account_reference', 'routing_reference', 'tax_identifier', 'contract_file_path'];

        foreach ($values as $key => $value) {
            if (in_array(strtolower((string) $key), $sensitive, true)) {
                $values[$key] = '[REDACTED]';
            } elseif (is_array($value)) {
                $values[$key] = $this->redact($value);
            }
        }

        return $values;
    }
}
