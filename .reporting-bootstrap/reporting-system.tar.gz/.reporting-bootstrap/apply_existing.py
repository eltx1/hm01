from pathlib import Path


def replace_once(path: str, old: str, new: str) -> None:
    file = Path(path)
    text = file.read_text()
    count = text.count(old)
    if count != 1:
        raise SystemExit(f'{path}: expected one occurrence, found {count}: {old[:80]!r}')
    file.write_text(text.replace(old, new, 1))

# Feed legacy campaign delivery imports into the unified reporting ledger.
replace_once(
    'app/Services/Campaigns/CampaignReportingService.php',
    'use App\\Services\\Gam\\GamConnectorManager;\n',
    'use App\\Services\\Gam\\GamConnectorManager;\nuse App\\Services\\Reporting\\AdvertiserFinancialService;\nuse App\\Services\\Reporting\\ReportingBridge;\n',
)
replace_once(
    'app/Services/Campaigns/CampaignReportingService.php',
    '        private readonly CampaignNetworkPlanner $planner,\n',
    '        private readonly CampaignNetworkPlanner $planner,\n        private readonly ReportingBridge $reportingBridge,\n        private readonly AdvertiserFinancialService $advertiserFinancials,\n',
)
replace_once(
    'app/Services/Campaigns/CampaignReportingService.php',
    '        $this->refreshGoals($instance->campaign);\n        return $count;\n',
    '        $this->refreshGoals($instance->campaign);\n        $this->reportingBridge->recordCampaignRows($instance, $rows);\n        $instance->campaign->invoices()->get()->each(fn ($invoice) => $this->advertiserFinancials->synchronizeInvoice($invoice));\n        return $count;\n',
)

# Feed existing native API/CSV imports into the unified reporting ledger.
replace_once(
    'app/Services/Demand/DemandReportService.php',
    'use App\\Services\\Audit\\AuditRecorder;\nuse Carbon\\CarbonInterface;\n',
    'use App\\Services\\Audit\\AuditRecorder;\nuse App\\Services\\Reporting\\ReportingBridge;\nuse Carbon\\CarbonImmutable;\nuse Carbon\\CarbonInterface;\n',
)
replace_once(
    'app/Services/Demand/DemandReportService.php',
    '        private readonly AuditRecorder $audit,\n',
    '        private readonly AuditRecorder $audit,\n        private readonly ReportingBridge $reportingBridge,\n',
)
replace_once(
    'app/Services/Demand/DemandReportService.php',
    "        $this->audit->record('demand.report.api_imported', $account->organization_id, $actor, $import, newValues: [\n            'row_count' => count($rows),\n            'period_start' => $from->toDateString(),\n            'period_end' => $to->toDateString(),\n        ]);\n\n        return $import->refresh();\n",
    "        $this->audit->record('demand.report.api_imported', $account->organization_id, $actor, $import, newValues: [\n            'row_count' => count($rows),\n            'period_start' => $from->toDateString(),\n            'period_end' => $to->toDateString(),\n        ]);\n        $this->reportingBridge->recordDemandRows(\n            $account,\n            $rows,\n            CarbonImmutable::parse($from),\n            CarbonImmutable::parse($to),\n            $actor,\n            null,\n            (string) ($import->external_report_id ?: 'demand-api:'.$import->id),\n            'DEMAND_API_BRIDGE',\n        );\n\n        return $import->refresh();\n",
)
replace_once(
    'app/Services/Demand/DemandReportService.php',
    "        $this->audit->record('demand.report.csv_imported', $account->organization_id, $actor, $import, newValues: [\n            'row_count' => count($rows),\n            'checksum' => $checksum,\n        ]);\n\n        return $import;\n",
    "        $this->audit->record('demand.report.csv_imported', $account->organization_id, $actor, $import, newValues: [\n            'row_count' => count($rows),\n            'checksum' => $checksum,\n        ]);\n        $this->reportingBridge->recordDemandRows(\n            $account,\n            $rows,\n            CarbonImmutable::parse($from),\n            CarbonImmutable::parse($to),\n            $actor,\n            $site,\n            'demand-csv:'.$checksum,\n            'DEMAND_CSV_BRIDGE',\n        );\n\n        return $import;\n",
)

# Initialize financial balance fields on campaign invoices.
replace_once(
    'app/Services/Campaigns/AdvertiserInvoiceService.php',
    "            'total_minor' => $subtotal + $tax,\n            'issued_on' => $issued,\n",
    "            'total_minor' => $subtotal + $tax,\n            'amount_paid_minor' => 0,\n            'balance_due_minor' => $subtotal + $tax,\n            'issued_on' => $issued,\n",
)
